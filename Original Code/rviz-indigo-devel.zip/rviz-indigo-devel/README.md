![rviz logo](https://raw.githubusercontent.com/ros-visualization/rviz/indigo-devel/images/splash.png)
[![Build Status](https://travis-ci.org/ros-visualization/rviz.svg?branch=indigo-devel)](https://travis-ci.org/ros-visualization/rviz)

rviz is a 3D visualiazer for the Robot Operating System (ROS) framework.

For more information, please see the wiki: http://wiki.ros.org/rviz
