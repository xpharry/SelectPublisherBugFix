# ros_helper_packages
useful ROS extensions, including catkin_simple and publish selected points

need to run: 
'catkin_make install'
in order to make the publish-selected-points plugin work with rviz

build-scripts contains handy scripts written at U. of Hong Kong to help simplify development, including
use of catkin-simple
